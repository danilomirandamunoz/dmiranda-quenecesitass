<?php
//include_once 'funciones.php';
?>
<!-- //////////////////////////////////
        //////////////MAIN HEADER/////////////
        ////////////////////////////////////-->
<!--  <div class="top-main-area text-left">
            <div class="container">
                <a href="index.html" class="logo mt5">
                    <img src="img\images.jpg" alt="Image Alternative text" title="Image Title" />
                </a>


            </div>
        </div>-->
<header class="main">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <!-- MAIN NAVIGATION -->
                <div class="flexnav-menu-button" id="flexnav-menu-button">Men&uacute;</div>
                <nav>
                    <ul class="nav nav-pills flexnav" id="flexnav" data-breakpoint="800">
                        <li><a href="/portal/home"><i class="fa fa-home"></i>Locales</a></li>
                        <!--  <li><a href="/portal/promociones"><i class="fa fa-gift"></i> Promociones</a></li>-->
                        <!--<li><a href="/portal/cercanos"><i class="fa fa-map-marker"></i> Los + Cercanos</a></li> -->

                        <!-- <li><a href="planes.html">Planes</a></li>-->
                    </ul>
                </nav>
                <!-- END MAIN NAVIGATION -->
            </div>

        </div>
    </div>
</header>

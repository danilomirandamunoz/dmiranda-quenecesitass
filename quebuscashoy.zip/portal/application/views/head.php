
    <!-- meta info -->
    <meta charset="utf-8" />
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type">
    <meta name="keywords" content="necesitas,que,empresas,articulos,locales,ofertas,institucion,ubicacion,localizacion,direccion empresa, direccion local,empresa,local">
    <meta name="description" content="Página dedicada a la búsqueda de Locales Comerciales y Productos.">

    <base href="<?php echo 1;//currentPageURL();?>" />
    <meta name="author" content="¿Qué Necesitas?">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="<?php echo $this->config->item('base_url');?>portal/img/earth_scan.ico" type="image/x-icon" />
    <link href='<?php echo $this->config->item('base_url');?>portal/css/font_open_sans.css' rel='stylesheet' type='text/css'>
    <link href='<?php echo $this->config->item('base_url');?>portal/css/font_roboto.css' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="<?php echo $this->config->item('base_url');?>portal/css/jquery-ui.css">
    <link rel="stylesheet" href="<?php echo $this->config->item('base_url');?>portal/css/jquery-ui.theme.css">
    <link rel="stylesheet" href="<?php echo $this->config->item('base_url');?>portal/css/boostrap.css">
    <link rel="stylesheet" href="<?php echo $this->config->item('base_url');?>portal/css/font_awesome.css">
    <link rel="stylesheet" href="<?php echo $this->config->item('base_url');?>portal/css/styles.css">
    <link rel="stylesheet" href="<?php echo $this->config->item('base_url');?>portal/css/mystyles.css">
    <link rel="stylesheet" href="<?php echo $this->config->item('base_url');?>portal/css/toastr.css">
    <link rel="stylesheet" type="text/css" href="https://js.api.here.com/v3/3.0/mapsjs-ui.css?dp-version=1533195059" />



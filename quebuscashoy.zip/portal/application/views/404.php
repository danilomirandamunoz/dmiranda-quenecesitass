<?php

?>
<!DOCTYPE html>
<html>
<head>
    <title>¿Qué Necesitas?</title>
    <!-- meta info -->
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type">
    <!-- Google fonts -->
    <link href='/portal/css/font_open_sans.css' rel='stylesheet' type='text/css'>
    <link href='/portal/css/font_roboto.css' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="/portal/css\boostrap.css">
    <link rel="stylesheet" href="/portal/css\styles.css">
</head>
<body >


    <div class="global-wrap">
        <!-- SEARCH AREA -->
        <!-- END SEARCH AREA -->
        <div class="gap-small">
        </div>
        <!-- //////////////////////////////////
        //////////////PAGE CONTENT/////////////
        ////////////////////////////////////-->
        <div class="container">
            <div class="gap-small">
        </div>
        <div class="gap-small">
        </div>
         <div class="gap">
                </div>
                 <div class="gap">
                </div>
                 <div class="gap">
                </div>
            <div class="row">

                <h1 class="title-hero">

	404

</h1>
            <h1>Lo Sentimos! La página que intentas acceder no existe.</h1>
            <div class="gap gap-small"></div><a href="/portal/home" class="btn btn-primary btn-mega">Volver al Home</a>
            <div class="gap"></div>




                <div class="gap">
                </div>
            </div>
        </div>

    </div>
</body>
</html>


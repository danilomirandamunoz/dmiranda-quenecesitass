﻿<footer class="main" id="main-footer">
    <div class="footer-copyright">
        <div class="container">
            <div class="row">
                <div class="col-md-6" style="text-align: center;">
                    <p>Copyright &copy; Todos los Derechos Reservados.</p>
                </div>
                <div class="col-md-6" style="text-align: center;">
                    <p>Cont&aacute;ctenos <a href="mailto:contacto@quenecesitas.cl">contacto@quenecesitas.cl</a></p>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Scripts queries -->
<script src="<?php echo $this->config->item('base_url');?>portal/js\jquery.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\jquery-ui.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\boostrap.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\countdown.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\flexnav.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\magnific.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\tweet.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\fitvids.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\mail.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\ionrangeslider.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\icheck.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\fotorama.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\card-payment.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\owl-carousel.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\masonry.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\nicescroll.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\custom.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\switcher.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\pagination.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js/jquery.blockui.min.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\autocomplete.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\bootbox.min.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\jquery.isloading.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\toastr.js"></script>
<script src="<?php echo $this->config->item('base_url');?>portal/js\funciones.js"></script>

<!--maps-->
<script type="text/javascript" src="https://js.api.here.com/v3/3.0/mapsjs-core.js"></script>
<script type="text/javascript" src="https://js.api.here.com/v3/3.0/mapsjs-service.js"></script>
<script type="text/javascript" src="https://js.api.here.com/v3/3.0/mapsjs-ui.js"></script>
<script type="text/javascript" src="https://js.api.here.com/v3/3.0/mapsjs-mapevents.js"></script>

 <script src="http://www.openlayers.org/api/OpenLayers.js"></script>

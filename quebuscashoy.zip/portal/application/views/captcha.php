<?php 

$_SESSION['6_letters_code'] = 1234;


?>
<label>Hola</label>
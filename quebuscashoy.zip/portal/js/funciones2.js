﻿$(function () {

    alert("hola");

});
 <div class="footer">
        <div class="footer-inner">
        </div>
        <div class="footer-tools">
            <span class="go-top"><i class="fa fa-angle-up"></i></span>
        </div>
    </div>
    <!-- END FOOTER -->
    <!-- BEGIN JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
    <!-- BEGIN CORE PLUGINS -->
    <!--[if lt IE 9]>
<script src="assets/plugins/respond.min.js"></script>
<script src="assets/plugins/excanvas.min.js"></script> 
<![endif]-->
    <script src="<?php echo $this->config->item('base_url');?>admin/js/jquery-1.10.2.min.js" type="text/javascript"></script>
    <script src="<?php echo $this->config->item('base_url');?>admin/js/jquery-migrate-1.2.1.min.js" type="text/javascript"></script>
    <script src="<?php echo $this->config->item('base_url');?>admin/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?php echo $this->config->item('base_url');?>admin/js/twitter-bootstrap-hover-dropdown.min.js"
        type="text/javascript"></script>
    <script src="<?php echo $this->config->item('base_url');?>admin/js/jquery.slimscroll.min.js" type="text/javascript"></script>
    <script src="<?php echo $this->config->item('base_url');?>admin/js/jquery.blockui.min.js" type="text/javascript"></script>
    <script src="<?php echo $this->config->item('base_url');?>admin/js/jquery.cokie.min.js" type="text/javascript"></script>
    <script src="<?php echo $this->config->item('base_url');?>admin/js/jquery.uniform.min.js" type="text/javascript"></script>
    <!-- END CORE PLUGINS -->
    <!-- BEGIN PAGE LEVEL PLUGINS -->
    <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>admin/js/spinner.min.js"></script>
    <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>admin/js/bootstrap-fileupload.js"></script>
    <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>admin/js/select2.min.js"></script>
    <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>admin/js/wysihtml5-0.3.0.js"></script>
    <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>admin/js/bootstrap-wysihtml5.js"></script>
    <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>admin/js/bootstrap-datepicker.js"></script>
    <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>admin/js/bootstrap-datetimepicker.js"></script>
    <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>admin/js/clockface.js"></script>
    <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>admin/js/moment.min.js"></script>
    <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>admin/js/daterangepicker.js"></script>
    <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>admin/js/bootstrap-timepicker.js"></script>
    <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>admin/js/jquery.inputmask.bundle.min.js"></script>
    <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>admin/js/jquery.input-ip-address-control-1.0.min.js"></script>
    <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>admin/js/jquery.multi-select.js"></script>
    <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>admin/js/jquery.quicksearch.js"></script>
    <script src="<?php echo $this->config->item('base_url');?>admin/js/pwstrength.js" type="text/javascript"></script>
    <script src="<?php echo $this->config->item('base_url');?>admin/js/bootstrap-switch.min.js" type="text/javascript"></script>
    <script src="<?php echo $this->config->item('base_url');?>admin/js/jquery.tagsinput.min.js" type="text/javascript"></script>
    <script src="<?php echo $this->config->item('base_url');?>admin/js/bootstrap-markdown.js" type="text/javascript"></script>
    <script src="<?php echo $this->config->item('base_url');?>admin/js/markdown.js" type="text/javascript"></script>
    <script src="<?php echo $this->config->item('base_url');?>admin/js/bootstrap-maxlength.min.js" type="text/javascript"></script>
    <script src="<?php echo $this->config->item('base_url');?>admin/js/bootstrap.touchspin.js" type="text/javascript"></script>
    <script src="<?php echo $this->config->item('base_url');?>admin/js/bootbox.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>admin/js/jquery.dataTables.js"></script>
    <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>admin/js/DT_bootstrap.js"></script>
    <script src="<?php echo $this->config->item('base_url');?>admin/js/bootbox.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>admin/js/jquery.validate.js"></script>
    <script type="text/javascript" src="<?php echo $this->config->item('base_url');?>admin/js/additional-methods.min.js"></script>
    <!-- END PAGE LEVEL PLUGINS -->
    <!-- BEGIN PAGE LEVEL SCRIPTS -->
    <script src="<?php echo $this->config->item('base_url');?>admin/js/app.js"></script>
    <script src="<?php echo $this->config->item('base_url');?>admin/js/form-components.js"></script>
    <script src="<?php echo $this->config->item('base_url');?>admin/js/custom.js"></script>
    <script src="<?php echo $this->config->item('base_url');?>admin/js/ui-bootbox.js"></script>
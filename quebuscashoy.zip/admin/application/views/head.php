    <meta charset="utf-8" />
    <title>Administración</title>
    <link rel="shortcut icon" href="<?php echo $this->config->item('base_url');?>admin/img/earth_scan.ico" type="image/x-icon" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta name="MobileOptimized" content="320">
    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="<?php echo $this->config->item('base_url');?>admin/css/font-awesome.min.css" rel="stylesheet"
        type="text/css" />
    <link href="<?php echo $this->config->item('base_url');?>admin/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo $this->config->item('base_url');?>admin/css/uniform.default.css" rel="stylesheet" type="text/css" />

    <!-- END GLOBAL MANDATORY STYLES -->
    <!-- BEGIN PAGE LEVEL STYLES -->
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('base_url');?>admin/css/bootstrap-fileupload.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('base_url');?>admin/css/bootstrap-wysihtml5.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('base_url');?>admin/css/datepicker.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('base_url');?>admin/css/timepicker.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('base_url');?>admin/css/daterangepicker-bs3.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('base_url');?>admin/css/datetimepicker.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('base_url');?>admin/css/multi-select.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('base_url');?>admin/css/bootstrap-switch-metro.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('base_url');?>admin/css/jquery.tagsinput.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('base_url');?>admin/css/bootstrap-markdown.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('base_url');?>admin/css/DT_bootstrap.css" />
    <!-- END PAGE LEVEL STYLES -->
    <!-- BEGIN THEME STYLES -->
    <link href="<?php echo $this->config->item('base_url');?>admin/css/style-metronic.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo $this->config->item('base_url');?>admin/css/style.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo $this->config->item('base_url');?>admin/css/style-responsive.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo $this->config->item('base_url');?>admin/css/plugins.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo $this->config->item('base_url');?>admin/css/themes/blue.css" rel="stylesheet" type="text/css" id="style_color">
    <link href="<?php echo $this->config->item('base_url');?>admin/css/custom.css" rel="stylesheet" type="text/css" />
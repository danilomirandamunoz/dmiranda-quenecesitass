<?php
echo "Acceso Restringido!";
?>